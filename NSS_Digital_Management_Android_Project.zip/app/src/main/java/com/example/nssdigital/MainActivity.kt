package com.example.nssdigital

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color

data class Student(val id:String,val name:String,val course:String,val year:String,val dept:String,val email:String)
data class Event(val name:String,val date:String,val year:String,val venue:String)

val students = listOf(
 Student("NSS001","Arun Kumar","B.Sc Computer Science","3rd Year","Computer Science","arun@example.com"),
 Student("NSS002","Priya S","B.A English","2nd Year","English","priya@example.com"),
 Student("NSS003","Karthik R","B.Com","3rd Year","Commerce","karthik@example.com"),
 Student("NSS004","Divya M","B.Sc Physics","1st Year","Physics","divya@example.com"),
 Student("NSS005","Vignesh P","BCA","2nd Year","Computer Applications","vignesh@example.com")
)
val events = listOf(
 Event("Clean Campus Drive","05 Jun 2025","2025-26","College Campus"),
 Event("Blood Donation Camp","15 Jul 2025","2025-26","College Auditorium")
)

@Composable fun App() {
    var loggedIn by remember { mutableStateOf(false) }
    var role by remember { mutableStateOf("Student") }
    var userId by remember { mutableStateOf("") }
    if (!loggedIn) LoginScreen({r,id -> role=r; userId=id; loggedIn=true}) else HomeScreen(role,userId,{loggedIn=false})
}

@Composable fun LoginScreen(onLogin:(String,String)->Unit) {
    var role by remember { mutableStateOf("Student") }
    var id by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement=Arrangement.Center) {
        Text("NSS", style=MaterialTheme.typography.displaySmall, color=Color(0xFF16834A))
        Text("NATIONAL SERVICE SCHEME", style=MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(28.dp))
        Text("Digital Management System", style=MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            listOf("Student","Volunteer","Admin").forEach { r ->
                FilterChip(selected=role==r,onClick={role=r},label={Text(r)})
            }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(id,{id=it},label={Text("NSS ID / Username")},modifier=Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(pass,{pass=it},label={Text("Password")},modifier=Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button(onClick={ if((role=="Student" && id=="NSS001" && pass=="student123") || (role=="Volunteer" && pass=="1234") || (role=="Admin" && id=="admin" && pass=="admin123")) onLogin(role,id) }, modifier=Modifier.fillMaxWidth()) { Text("LOGIN") }
        Spacer(Modifier.height(12.dp))
        Text("Demo: NSS001 / student123   •   admin / admin123")
    }
}

@Composable fun HomeScreen(role:String,userId:String,onLogout:()->Unit) {
    var page by remember { mutableStateOf("Dashboard") }
    val menu = listOf("Dashboard","Profile","Events","Attendance","Achievements","Certificates","NSS Impact","Notifications")
    val student = students.find{it.id==userId} ?: students.first()
    Row(Modifier.fillMaxSize()) {
        NavigationRail {
            Text("NSS",Modifier.padding(12.dp),color=Color(0xFF16834A),style=MaterialTheme.typography.titleLarge)
            menu.forEach { m -> NavigationRailItem(selected=page==m,onClick={page=m},icon={},label={Text(m)}) }
        }
        Column(Modifier.fillMaxSize().padding(18.dp)) {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                Text(page,style=MaterialTheme.typography.headlineSmall)
                TextButton(onClick=onLogout){Text("Logout")}
            }
            Spacer(Modifier.height(12.dp))
            when(page){
                "Dashboard" -> Dashboard(role,student)
                "Profile" -> Profile(student)
                "Events" -> EventsPage()
                "Attendance" -> AttendancePage(student)
                "Achievements" -> InfoPage("Achievements",listOf("Best Volunteer — Clean Campus Drive","Participation certificate available"))
                "Certificates" -> InfoPage("Certificates",listOf("Upload certificates from your device","Admin can view submitted certificates"))
                "NSS Impact" -> InfoPage("NSS Activity & Impact",listOf("Clean Campus Drive","Blood Donation Camp","Community participation","Digital record tracking"))
                else -> InfoPage("Notifications",listOf("Welcome to NSS Digital Management System"))
            }
        }
    }
}

@Composable fun Dashboard(role:String,s:Student){
    LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp)){
        item { Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color(0xFFE9F7EF))){Column(Modifier.padding(18.dp)){Text("Welcome, ${s.name}",style=MaterialTheme.typography.headlineSmall);Text("Role: $role")}}}
        item { Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Stat("Events","2");Stat("Attendance","2");Stat("Certificates","0")}}
        item { Text("Quick Modules",style=MaterialTheme.typography.titleLarge) }
        items(listOf("Events","Attendance","Achievements","Certificates","NSS Impact","Notifications")){x->Card(Modifier.fillMaxWidth()){Text(x,Modifier.padding(18.dp),style=MaterialTheme.typography.titleMedium)}}
    }
}
@Composable fun Stat(a:String,b:String){Card(Modifier.weight(1f)){Column(Modifier.padding(14.dp)){Text(b,style=MaterialTheme.typography.headlineMedium);Text(a)}}}
@Composable fun Profile(s:Student){Card{Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Digital ID",style=MaterialTheme.typography.titleLarge);Text("NSS ID: ${s.id}");Text("Name: ${s.name}");Text("Course: ${s.course}");Text("Year: ${s.year}");Text("Department: ${s.dept}");Text("Email: ${s.email}")}}}
@Composable fun EventsPage(){LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(events){e->Card{Column(Modifier.padding(16.dp)){Text(e.name,style=MaterialTheme.typography.titleLarge);Text("${e.date} • ${e.year}");Text(e.venue)}}}}}
@Composable fun AttendancePage(s:Student){InfoPage("Attendance",listOf("Clean Campus Drive — Present — 4 hours","Blood Donation Camp — Present — 5 hours","Student: ${s.id}"))}
@Composable fun InfoPage(title:String,items:List<String>){LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text(title,style=MaterialTheme.typography.titleLarge)};items(items){x->Card{Text(x,Modifier.padding(16.dp))}}}}
